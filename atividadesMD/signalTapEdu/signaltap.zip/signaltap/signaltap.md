# Aula  - Atividade (Tutorial-Signaltap-Intel) 

- Nesta atividade iremos verificar como captar e analisar sinais de uma FPGA elaborada, a fins de procurar erros lógicos ou de funcionamento ("debug").

- Para isto, iremos utilizar o software incluso no ambiente da Altera, o software Signaltap.

- Antes de continuar com o conteúdo a seguir da atividade, pedimos que realizem o guia introdutório básico do Signaltap até o fim do capítulo 7.1, o conteúdo está no Blackboard com o nome "Aula  - Atividade (Tutorial-Signaltap-Intel)".

- Continuando apartir do exemplo anterior, crie uma memória RAM de 4-bits de endereço com 4-bits de dados. A memória deve ter uma estrutura similar a seguir:

```
component ram2
generic 
	(
		DATA_WIDTH : natural := 4;
		ADDR_WIDTH : natural := 4
	);

	port 
	(
		clk		: in std_logic;
		addr	: in natural range 0 to 2**ADDR_WIDTH - 1;
		data	: in std_logic_vector((DATA_WIDTH-1) downto 0);
		we		: in std_logic := '1';
		q		: out std_logic_vector((DATA_WIDTH -1) downto 0)
	);
end component;
```
 
 - Realize o port-map da entidade com o top-level **keys** do exemplo da Altera, ligue as chaves junto com o endereçamento e os dados (para você poder manipular). Ligue os LEDs junto com a saída da RAM e o Write Enable (we) é recomendado que seja ligado em um botão.   
 Dica: botão -> KEY; LEDs -> LEDR; chaves -> SW    
 Outra dica: cuidado na ligação do Write Enable.

 - Compile o projeto e verifique se você consegue ver o funcionamento da RAM de forma correta. Dica: tente armazenar dados distintos em cada endereço, e verifique se trocar entre os endereços, os valores corretos aparecem. Observe que para gravar na RAM, você deverá apertar o botão ligado ao Write Enable.

 - Será que é possível "debugar" este projeto para verificar detalhes importantes como: obter o valor dos dados em cada alteração dos endereços? Verificar os efeitos da temporização (os dados trocam instantaneamente?) Como tirar uma "fotografia" dos sinais a qualquer momento? Tudo é possível com o Signaltap.

 - Abra o Signaltap, e na aba Setup adicione os sinais LEDR, KEY, SW.
![](imagens/sinais_add.png)

- Na aba Setup, lembre-se também de configurar o sinal de clock, CLOCK_50.
![](imagens/clock.png)

- Configure a entrada no qual o sinal Write Enable está conectado como Trigger com o botão direito (no caso valor zero, valor no qual é acionado.)     
![](imagens/trigger.png)

- Compile o projeto e programe a FPGA. Verifique se ao apertar o botão, são mostrados os sinais capturados.    
![](imagens/grafico_sinais.png)

- Clique com o botão direito no eixo superior e adicione uma escala de tempo bem definida (exemplo: 10ns)    
![](imagens/sinais_tempo.png)

- Qual o tempo aproximado para propagação do sinal de alteração, considerando o tempo do botão até alterar nos LEDs?
![](imagens/alteracao_tempo.png)

- Vamos ver outras formas de Trigger, vá novamente na aba Setup e na parte de Signal Configuration, retire a condição de Trigger do botão ligado ao Write Enable. Vamos agora colocar uma condição de Either Edge (ambas as bordas) nos sinais de endereçamento da RAM.    
![](imagens/either_edge.png)

- Ao finalizar, os sinais de endereçamento deve estar similar ao da figura (todos com Either Edge) e em cima configurado como Basic OR.
![](imagens/config.png)

- Compile e programe o projeto. Utilize agora a opção Autorun Analysis, e perceba que na aba Data, em qualquer alteração das chaves de endereço, automaticamente obteremos uma foto do que ocorre com os sinais.
![](imagens/config.png)

- Observe que na transição de alguns sinais como chaves e botões, alguns fenomênos como o circulado em vermelho ocorre. O que isto quer dizer? Porque o sinal oscila? Isto pode acarretar dados no funcionamento do circuito? Existem maneiras de reduzir este efeito? Reflita.
![](imagens/sinais_evidente.png)

- Observe que o Signaltap pode ser configurado para qualquer I/O da FPGA, e podemos utiliza-lo para obter uma "fotografia" dos sinais, podendo ser muito útil para testes e verificar funcionamento lógico de circuitos projetos.